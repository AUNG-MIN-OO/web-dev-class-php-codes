<?php include "template/header.php"; ?>

<h1>This is contact Page</h1>

<?php include "template/footer.php"; ?>