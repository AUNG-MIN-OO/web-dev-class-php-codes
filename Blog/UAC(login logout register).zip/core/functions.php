<?php
//common start
function alert ($data,$color="danger"){
    return "<p class='alert alert-$color'>$data</p>";
}

function runQuery ($sql){
    if (mysqli_query(con(),$sql)) {
        return true;
    } else {
        die("Query Fail : ".mysqli_error($sql));
    }
    
}

function redirection($l){
    header("location:$l");
}

//common end

//authentication start

function register (){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cPassword = $_POST['cPassword'];

    if ($password == $cPassword){
        $sPass = password_hash($password,PASSWORD_DEFAULT);
        $sql = "INSERT INTO users(name,email,password) VALUES('$name','$email','$sPass')";
        if (runQuery($sql)){
            redirection("login.php");
        }
    }else{
        return alert("Password don't match");
    }
}

function login(){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email='$email'";
    $query = mysqli_query(con(),$sql);
    $row = mysqli_fetch_assoc($query);
    if (!$row){
        return alert("Email or Password does not match") ;
    }else{
        if (!password_verify($password,$row['password'])){
            return alert("Email or Password does not match") ;
        }else{
            session_start();
            $_SESSION['user'] = $row ;
            redirection("dashboard.php");
        }
    }

}

//authentication end